﻿define("epi-cms/component/command/GlobalToolbarCommandProvider", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/Deferred",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",

    "dijit/form/ToggleButton",
    "dijit/layout/ContentPane",

    "epi/dependency",
    "epi/shell/ViewSettings",
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",

    "epi/shell/ViewSettings",

    "epi/shell/widget/ExpandoButton",

    "epi-cms/widget/ViewSettingsExpandoButton",
    "epi-cms/widget/VisitorGroupButton",
    "epi-cms/widget/ChannelsButton",
    "epi-cms/widget/ViewLanguageButton",
    "epi-cms/widget/command/CreateContentFromSelector",

    "epi-cms/component/command/_GlobalToolbarCommandProvider",

// Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"

],

function (
    array,
    declare,
    Deferred,
    lang,
    topic,
    when,

    ToggleButton,
    ContentPane,

    dependency,
    viewSettings,
    _Command,
    ToggleCommand,

    ViewSettings,

    ExpandoButton,

    ViewSettingsExpandoButton,
    VisitorGroupButton,
    ChannelsButton,
    ViewLanguageButton,
    CreateContentFromSelector,

    _GlobalToolbarCommandProvider,

    resources
) {

    var _ToggleNavigationPaneCommand = declare([ToggleCommand], {
        iconClass: "epi-iconTree",
        tooltip: resources.toolbar.buttons.togglenavigationpane,
        label: resources.toolbar.buttons.togglenavigationpane,
        canExecute: true,
        constructor: function () {
            topic.subscribe("/epi/layout/pinnable/navigation/visibilitychanged", lang.hitch(this, function (visible) {
                this.set("active", visible);
            }));
        },
        _execute: function () {
            topic.publish("/epi/layout/pinnable/navigation/toggle");
        }

    });

    var _ToggleAssetsPaneCommand = declare([ToggleCommand], {
        iconClass: "epi-iconFolder",
        tooltip: resources.toolbar.buttons.toggleassetspane,
        label: resources.toolbar.buttons.toggleassetspane,
        canExecute: true,
        constructor: function () {
            topic.subscribe("/epi/layout/pinnable/tools/visibilitychanged", lang.hitch(this, function (visible) {
                this.set("active", visible);
            }));
        },
        _execute: function () {
            topic.publish("/epi/layout/pinnable/tools/toggle");
        }
    });

    var _ViewSettingCommand = declare([_Command], {
        iconClass: "epi-iconEye",
        canExecute: true,
        label: resources.toolbar.buttons.viewsetting.viewsettingbutton,

        constructor: function () {
            // Hide the button if the current view component is not "epi-cms/contentediting/PageDataController"
            // In other words, it will be hidden when creating new content or viewing Trash page
            topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (view) {
                // NOTE: This needs to be revised when changing the view loading.
                this.set("isAvailable", typeof view != "string" || view == "epi-cms/contentediting/PageDataController");
            }));
        }
    });

    var _TogglePreviewModeCommand = declare([ToggleCommand], {
        iconClass: "epi-iconPreview",
        tooltip: resources.toolbar.buttons.togglepreviewmode.label,
        label: resources.toolbar.buttons.togglepreviewmode.label,
        canExecute: true,

        constructor: function () {
            this._profile = dependency.resolve("epi.shell.Profile");
            this._setPanelSettings();

            // Deactivate the option if we recieve a disable topic.
            topic.subscribe("/epi/cms/action/disablepreview", lang.hitch(this, function () {
                this.set("active", false);
                this._restoreSidePanels();
            }));

            // Hide the button if the current view component is not "epi-cms/contentediting/PageDataController"
            // In other words, it will be hidden when creating new content or viewing Trash page
            topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (view) {
                // NOTE: This needs to be revised when changing the view loading.
                var enable = typeof view != "string" || view == "epi-cms/contentediting/PageDataController";
                if(!enable && this.active) {
                    this.execute();
                }
                this.set("isAvailable", enable);
            }));
        },

        _restoreSidePanels: function () {
            topic.publish("/epi/layout/pinnable/navigation/toggle", this.get("isNavigationVisible"));
            topic.publish("/epi/layout/pinnable/tools/toggle", this.get("isToolsVisible"));
        },

        _hideSidePanels: function(){
            this._setPanelSettings();
            topic.publish("/epi/layout/pinnable/navigation/toggle", false);
            topic.publish("/epi/layout/pinnable/tools/toggle", false);
        },

        _setPanelSettings: function(){
            when(this._profile.get("navigation"), lang.hitch(this, function(navigationSetting){
                this.set("isNavigationVisible", navigationSetting.visible);
            }));
            when(this._profile.get("tools"), lang.hitch(this, function(toolsSetting){
                this.set("isToolsVisible", toolsSetting.visible);
            }));
        },

        _execute: function () {
            this.set("active", !this.active);

            if (this.active) {
                this._hideSidePanels();
                topic.publish("/epi/shell/action/changeview", "view");
            } else {
                this._restoreSidePanels();
                topic.publish("/epi/shell/action/changeview/back", true);
            }
        }
    });

    // module:
    //      epi-cms/component/command/GlobalToolbarCommandProvider
    // summary:
    //      Default command provider for the epi-cms/component/GlobalToolbar
    // tags:
    //      private
    return declare([_GlobalToolbarCommandProvider], {

        contentRepositoryDescriptors: null,
        viewName: null,

        postscript: function () {
            // summary:
            //      Ensure that an array of commands has been initialized.
            // tags:
            //      public
            this.inherited(arguments);

            this.contentRepositoryDescriptors = this.contentRepositoryDescriptors || dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.viewName = this.viewName || viewSettings.viewName;
            this._addLeadingCommands();

            this._addCreateCommands();

            this._addViewCommands();

            this._addTrailingCommands();
        },

        _addLeadingCommands: function () {
            this.addToLeading(new _ToggleNavigationPaneCommand(), {
                widget: ToggleButton,
                "class": "epi-leadingToggleButton epi-mediumButton"
            });
        },

        _addCreateCommands: function () {

            var currentView = this.viewName;
            var descriptorsForCurrentView = [];
            var isCurrentView = function(view){
                return view == currentView;
            };

            for(var index in this.contentRepositoryDescriptors){
                var descriptor = this.contentRepositoryDescriptors[index];
                if (array.some(descriptor.mainViews, isCurrentView)){
                    descriptorsForCurrentView.push(descriptor);
                }
            }

            array.forEach(descriptorsForCurrentView, function(descriptor){
                array.forEach(descriptor.creatableTypes, function(type){
                    this.addCommand(this._createCommand(type), {category: "create"});
                },this);
            },this);
        },

        _createCommand: function(type){
            return new CreateContentFromSelector({
                creatingTypeIdentifier: type
            });
        },

        _addViewCommands: function () {
            // View settings expando button
            this.addCommand(new _ViewSettingCommand(), {
                widget: ViewSettingsExpandoButton,
                showInGroup: true,
                buttons: [new ViewLanguageButton(), new VisitorGroupButton(), new ChannelsButton()],
                category: "view"
            });

            // Preview expando button
            this.addCommand(new _TogglePreviewModeCommand(), {
                widget: ExpandoButton,
                showInGroup: true,
                hasToggleableChildren: false,
                buttons: [new ContentPane({
                    iconClass: "",
                    "class": "epi-expandoButtonActiveNode",
                    content: "<span>" + resources.toolbar.buttons.togglepreviewmode.message + "</span>"
                })],
                category: "view"
            });
        },

        _addTrailingCommands: function () {
            this.addToTrailing(new _ToggleAssetsPaneCommand(), {
                widget: ToggleButton,
                "class": "epi-trailingToggleButton epi-mediumButton"
            });
        }
    });
});
