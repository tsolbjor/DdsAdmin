﻿define("epi-cms/contentediting/commandproviders/ContentDetails", [
    "dojo",
    "dojo/_base/declare",

    "epi/shell/command/_CommandProviderMixin",

    "../command/PermanentInUseToggle",
    "../command/StartWorkflow"
], function (
    dojo,
    declare,

    _CommandProviderMixin,
    PermanentInUseToggle,
    StartWorkflow) {

    // module:
    //		epi-cms/contentediting/commandproviders/ContentDetails
    // summary:
    //		Command provider, which adds in use notification related commands to content detail area.

    return declare([_CommandProviderMixin], {

        constructor: function () {
            // summary:
            //		Ensure that an array of commands has been initialized.
            // tags:
            //		public            
            this.inherited(arguments);

            // permanent inuse notification toggle
            this.add("commands", new PermanentInUseToggle());
            this.add("commands", new StartWorkflow());
        }
    });
});
