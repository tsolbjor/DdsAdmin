require({cache:{
'url:epi-cms/contentediting/templates/ScheduledPublishSelector.html':"﻿<div>\r\n    <div data-dojo-type=\"epi-cms/widget/Breadcrumb\" data-dojo-attach-point=\"breadcrumbNode\" data-dojo-props=\"showCurrentNode: false\"></div>\r\n    <h1 data-dojo-attach-point=\"contentNameNode\" class=\"epi-breadCrumbsCurrentItem dijitInline dojoxEllipsis\"></h1>\r\n    <div data-dojo-attach-point=\"publishChangesCaptionNode\"></div>\r\n    <div data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"dateTimeSelector\" data-dojo-props=\"required:true\"></div>\r\n</div>"}});
﻿define("epi-cms/contentediting/ScheduledPublishSelector", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

// Dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

//EPi
    "epi/shell/widget/_ActionProviderWidget",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/DateTimeSelectorDropDown",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi-cms/widget/Breadcrumb",
    "./ScheduledPublishSelectorViewModel",

// Resources
    "dojo/text!./templates/ScheduledPublishSelector.html",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.scheduledpublishselector",
    "epi/i18n!epi/nls/episerver.shared"
],

function (
// Dojo
    declare,
    lang,

// Dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

// EPi
    _ActionProviderWidget,
    _ModelBindingMixin,
    DateTimeSelectorDropDown,
    _DialogContentMixin,
    Breadcrumb,
    ScheduledPublishSelectorViewModel,

// Resources
    template,
    resources,
    sharedResources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _ActionProviderWidget, _DialogContentMixin], {
        // summary:
        //    A widget for selecting date when doing a scheduled publish.
        //
        // tags:
        //    public

        templateString: template,

        modelData: null,

        _setTitleAttr: {
            node: "contentNameNode",
            type: "innerText"
        },

        _setDateLabelAttr: {
            node: "publishChangesCaptionNode",
            type: "innerHTML"
        },

        _setDateValueAttr: function (date) {
            this.dateTimeSelector.set("value", date);
        },

        _setBreadcrumbModelAttr: function (breadcrumbModel) {
            this.breadcrumbNode.set("contentLink", breadcrumbModel);
        },

        _setScheduleButtonEnabledAttr: function (enabled) {
            if (this._actions && this._actions.length) {
                this.setActionProperty("save", "disabled", !enabled);
            }
        },

        modelBindingMap: {
            "title": ["title"],
            "dateLabel": ["dateLabel"],
            "dateValue": ["dateValue"],
            "breadcrumbModel": ["breadcrumbModel"],
            "scheduleButtonEnabled": ["scheduleButtonEnabled"]
        },

        postMixInProperties: function () {
            this.inherited(arguments);

            this.model = this.model || new ScheduledPublishSelectorViewModel(this.modelData);
        },

        postCreate: function () {
            // summary:
            //
            // tags:
            //      protected
            this.inherited(arguments);

            this.connect(this.dateTimeSelector, "onChange", "dateTimeSelectorChanged");
        },

        dateTimeSelectorChanged: function (value) {
            this.model.set("dateValue", value);
        },

        getActions: function () {
            // summary:
            //      Overridden from _ActionProvider to get the select current content action added to the containing widget
            //
            // returns:
            //      An array containing a select page action definition, if it is not a shared block

            this._actions = [
                {
                    name: "save",
                    label: resources.confirmtext,
                    settings: { type: "button", "class": "Salt", disabled: true },
                    action: lang.hitch(this, function () {
                        if (this.dateTimeSelector.validate()) {
                            this.executeDialog();
                        }
                    })
                },
                {
                    name: "cancel",
                    label: sharedResources.action.cancel,
                    settings: { type: "button" },
                    action: lang.hitch(this, function () {
                        this.cancelDialog();
                    })
                }
            ];

            return this._actions;
        }
    });
});