﻿define("epi-cms/component/command/ViewTrash", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",
    "dojo/topic",

// Epi Framework
    "epi/dependency",
    "epi/shell/command/_Command",

// EPi CMS
    "epi-cms/ApplicationSettings",

// Resource
    "epi/i18n!epi/cms/nls/episerver.cms.command"
], function (
// Dojo base
    declare,
    lang,
    Deferred,
    topic,

// Epi Framework
    dependency,
    _Command,

// EPi CMS
    ApplicationSettings,

// Resource
    resources

    ) {

    // module:
    //		epi/cms/component/command/ViewTrash
    // summary:
    //		A command that opens the trash.

    return declare([_Command], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: resources.viewtrash,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        _wasteBasketId: null,

        typeIdentifiers: null,

        postscript: function () {
            this.inherited(arguments);

            // Set default cannot execute for view trash command
            this.set("canExecute", false);

            this._wasteBasketId = ApplicationSettings.wastebasketPage;
            var store = dependency.resolve("epi.storeregistry").get("epi.cms.content.light");

            // this should be able to be execute when user have READ access right for trash
            Deferred.when(store.get(this._wasteBasketId), lang.hitch(this, function (response) {
                this.set("canExecute", (response.statusCode != "401"));
            }));
        },

        _execute: function () {
            // summary:
            //		Executes this command; publishes a change view request to change to the view trash view.
            // tags:
            //		protected

            topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + this._wasteBasketId }, 
                {sender: this, typeIdentifiers: this.typeIdentifiers });
        }
    });
});
