//>>built
define("epi-cms/contentediting/PageShortcutTypeSupport",[],function(){var _1={pageShortcutTypes:{Normal:0,Shortcut:1,External:2,Inactive:3,FetchData:4}};return _1;});